/* =========================================================
   DATOS FICTICIOS DE DEMOSTRACIÓN
   Sustituye estos registros por datos de API/base de datos
   cuando la aplicación tenga un backend real.
   ========================================================= */
const SAMPLE_TRANSACTIONS = [
  { id: "FC-1048", customer: "Laura Méndez", initials: "LM", merchant: "Mercado Verde", category: "Supermercado", amount: 186500, location: "Bogotá, Colombia", time: "10:42 a. m.", score: 12, status: "approved", device: "Habitual" },
  { id: "FC-1047", customer: "Andrés Rojas", initials: "AR", merchant: "Nova Tecnología", category: "Electrónica", amount: 2840000, location: "Miami, Estados Unidos", time: "10:38 a. m.", score: 84, status: "blocked", device: "Nuevo" },
  { id: "FC-1046", customer: "Camila Torres", initials: "CT", merchant: "Café Olivo", category: "Restaurante", amount: 68400, location: "Medellín, Colombia", time: "10:31 a. m.", score: 18, status: "approved", device: "Habitual" },
  { id: "FC-1045", customer: "Mateo Vargas", initials: "MV", merchant: "Viajes Horizonte", category: "Viajes", amount: 1320000, location: "Bogotá, Colombia", time: "10:24 a. m.", score: 48, status: "review", device: "Nuevo" },
  { id: "FC-1044", customer: "Sofía Ramírez", initials: "SR", merchant: "StreamPlay", category: "Servicios digitales", amount: 42900, location: "Cali, Colombia", time: "10:18 a. m.", score: 9, status: "approved", device: "Habitual" },
  { id: "FC-1043", customer: "Daniel Castro", initials: "DC", merchant: "ElectroMundo", category: "Electrónica", amount: 980000, location: "Ciudad de México, México", time: "10:09 a. m.", score: 57, status: "review", device: "Habitual" },
  { id: "FC-1042", customer: "Valentina Gil", initials: "VG", merchant: "Mercado Verde", category: "Supermercado", amount: 215700, location: "Bogotá, Colombia", time: "9:56 a. m.", score: 15, status: "approved", device: "Habitual" },
  { id: "FC-1041", customer: "Nicolás Peña", initials: "NP", merchant: "Billetera Digital", category: "Servicios digitales", amount: 3750000, location: "Madrid, España", time: "9:48 a. m.", score: 91, status: "blocked", device: "Nuevo" }
];

const REFERENCE_METRICS = {
  totalProcessed: 12458,
  modelAccuracy: 97.6,
  responseSeconds: 1.2
};

const STATUS_INFO = {
  approved: { label: "Legítima", action: "Pago aprobado", headline: "Operación de bajo riesgo", description: "Las señales ingresadas se parecen al comportamiento habitual de la cuenta." },
  review: { label: "Por verificar", action: "Verificación adicional", headline: "Recomendamos una revisión", description: "Se encontraron señales que conviene confirmar antes de autorizar la operación." },
  blocked: { label: "Sospechosa", action: "Pago bloqueado", headline: "Operación de alto riesgo", description: "La combinación de señales eleva el riesgo en esta simulación." }
};

/* =========================================================
   LÓGICA DE INTERFAZ
   ========================================================= */
const appState = {
  transactions: SAMPLE_TRANSACTIONS.map((transaction) => ({ ...transaction })),
  sessionAnalyses: [],
  activePage: "inicio"
};

const PAGE_LABELS = {
  inicio: "Resumen general",
  datos: "Datos de transacciones",
  modelo: "Modelo de detección",
  monitoreo: "Monitoreo en tiempo real",
  resultados: "Resultados y métricas"
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

function formatNumber(value) {
  return new Intl.NumberFormat("es-CO", { maximumFractionDigits: 0 }).format(value);
}

function formatCurrency(value) {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0
  }).format(value);
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[character]));
}

function getStatusInfo(status) {
  return STATUS_INFO[status] || STATUS_INFO.review;
}

function transactionRow(transaction, includeLocation = false) {
  const statusInfo = getStatusInfo(transaction.status);
  const riskLevel = transaction.score >= 65 ? "high" : transaction.score >= 35 ? "medium" : "low";
  const riskLabel = riskLevel === "high" ? "Alto" : riskLevel === "medium" ? "Medio" : "Bajo";
  const safeId = escapeHTML(transaction.id);
  return `
    <tr>
      <td><span class="transaction-id"><span class="table-card-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/></svg></span>${safeId}</span></td>
      <td><span class="customer-name">${escapeHTML(transaction.customer)}</span></td>
      <td><span class="merchant-cell">${escapeHTML(transaction.merchant)}</span></td>
      <td class="amount-cell">${formatCurrency(transaction.amount)}</td>
      ${includeLocation ? `<td>${escapeHTML(transaction.location)}</td>` : ""}
      <td><span class="risk-pill risk-${riskLevel}">${riskLabel} · ${transaction.score}</span></td>
      <td><span class="status-pill status-${transaction.status}">${statusInfo.label}</span></td>
    </tr>`;
}

function updateOverview() {
  const totals = appState.transactions.reduce((counts, transaction) => {
    counts[transaction.status] = (counts[transaction.status] || 0) + 1;
    return counts;
  }, { approved: 0, review: 0, blocked: 0 });
  const total = appState.transactions.length;
  const totalLabel = String(total).padStart(2, "0");

  $("#nav-data-count").textContent = totalLabel;
  $("#metric-review").textContent = String(totals.review).padStart(2, "0");
  $("#decision-total").textContent = totalLabel;
  $("#count-approved").textContent = String(totals.approved).padStart(2, "0");
  $("#count-review").textContent = String(totals.review).padStart(2, "0");
  $("#count-blocked").textContent = String(totals.blocked).padStart(2, "0");
  $("#bar-approved").style.width = total ? `${(totals.approved / total) * 100}%` : "0";
  $("#bar-review").style.width = total ? `${(totals.review / total) * 100}%` : "0";
  $("#bar-blocked").style.width = total ? `${(totals.blocked / total) * 100}%` : "0";
  $("#home-transactions-body").innerHTML = appState.transactions.slice(0, 5).map((item) => transactionRow(item)).join("");
  $("#home-table-count").textContent = `Mostrando ${Math.min(5, total)} registros`;

  const visibleCount = $("#data-count-stat");
  if (visibleCount) {
    visibleCount.textContent = totalLabel;
    $("#data-approved-stat").textContent = String(totals.approved).padStart(2, "0");
    $("#data-risk-stat").textContent = String(totals.review + totals.blocked).padStart(2, "0");
    const totalAmount = appState.transactions.reduce((sum, transaction) => sum + transaction.amount, 0);
    $("#data-amount-stat").textContent = formatCurrency(totalAmount);
  }
}

function getFilteredTransactions() {
  const query = ($("#transaction-search")?.value || "").trim().toLocaleLowerCase("es");
  const status = $("#status-filter")?.value || "all";
  const risk = $("#risk-filter")?.value || "all";
  return appState.transactions.filter((transaction) => {
    const matchesQuery = !query || [
      transaction.id, transaction.customer, transaction.merchant, transaction.category,
      transaction.location, transaction.device
    ].some((field) => field.toLocaleLowerCase("es").includes(query));
    const matchesStatus = status === "all" || transaction.status === status;
    const level = transaction.score >= 65 ? "high" : transaction.score >= 35 ? "medium" : "low";
    const matchesRisk = risk === "all" || level === risk;
    return matchesQuery && matchesStatus && matchesRisk;
  });
}

function renderDataTable() {
  const filtered = getFilteredTransactions();
  $("#all-transactions-body").innerHTML = filtered.map((item) => transactionRow(item, true)).join("");
  $("#empty-state").hidden = filtered.length > 0;
  $(".table-wrap", $("#page-datos")).hidden = filtered.length === 0;
  $("#record-count").textContent = `${filtered.length} ${filtered.length === 1 ? "registro" : "registros"}`;
  $("#table-count-label").textContent = `Mostrando ${filtered.length} de ${appState.transactions.length} registros`;
}

function setPage(page) {
  if (!PAGE_LABELS[page]) return;
  appState.activePage = page;
  $$(".page").forEach((section) => {
    const active = section.id === `page-${page}`;
    section.classList.toggle("is-visible", active);
    section.hidden = !active;
  });
  $$(".nav-item").forEach((item) => {
    const active = item.dataset.page === page;
    item.classList.toggle("is-active", active);
    if (active) item.setAttribute("aria-current", "page");
    else item.removeAttribute("aria-current");
  });
  $("#current-section").textContent = PAGE_LABELS[page];
  if (page === "datos") renderDataTable();
  closeMobileMenu();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function showToast(message) {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<span class="toast-mark" aria-hidden="true">✓</span><span>${escapeHTML(message)}</span>`;
  $("#toast-region").append(toast);
  window.setTimeout(() => toast.remove(), 3400);
}

function closeMobileMenu() {
  $("#sidebar").classList.remove("is-open");
  $("#sidebar-backdrop").classList.remove("is-visible");
  $("#mobile-menu-button").setAttribute("aria-expanded", "false");
}

function toggleMobileMenu() {
  const sidebar = $("#sidebar");
  const isOpen = sidebar.classList.toggle("is-open");
  $("#sidebar-backdrop").classList.toggle("is-visible", isOpen);
  $("#mobile-menu-button").setAttribute("aria-expanded", String(isOpen));
}

function classifyTransaction(formData) {
  const amount = Number(formData.get("amount"));
  const location = String(formData.get("location"));
  const device = String(formData.get("device"));
  const merchant = String(formData.get("merchant"));
  const velocity = String(formData.get("velocity"));
  const time = String(formData.get("time"));
  let score = 8;
  const reasons = [];

  if (amount > 2500000) {
    score += 35;
    reasons.push({ text: "Monto muy por encima del patrón habitual", triggered: true });
  } else if (amount > 1200000) {
    score += 23;
    reasons.push({ text: "Monto elevado frente al comportamiento típico", triggered: true });
  } else {
    reasons.push({ text: "Monto dentro de un rango frecuente", triggered: false });
  }

  if (!location.endsWith("Colombia")) {
    score += 24;
    reasons.push({ text: "Ubicación fuera del país habitual", triggered: true });
  } else {
    reasons.push({ text: "Ubicación nacional conocida", triggered: false });
  }

  if (device === "new") {
    score += 22;
    reasons.push({ text: "Dispositivo no registrado anteriormente", triggered: true });
  } else {
    reasons.push({ text: "Dispositivo habitual", triggered: false });
  }

  if (velocity === "elevated") {
    score += 19;
    reasons.push({ text: "Varios intentos en un intervalo corto", triggered: true });
  } else {
    reasons.push({ text: "Sin actividad inusual reciente", triggered: false });
  }

  if (time === "unusual") {
    score += 10;
    reasons.push({ text: "Horario diferente al habitual", triggered: true });
  }

  if (["tecnologia", "digital", "viajes"].includes(merchant)) {
    score += 8;
    reasons.push({ text: "Categoría de comercio considerada sensible", triggered: true });
  }

  score = Math.min(99, score);
  const status = score >= 65 ? "blocked" : score >= 35 ? "review" : "approved";
  return { amount, location, device, merchant, score, status, reasons };
}

function statusIconSVG(status) {
  if (status === "approved") return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>';
  if (status === "blocked") return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8v5m0 4h.01"/><path d="M10.3 3.9 2.7 17a2 2 0 0 0 1.7 3h15.2a2 2 0 0 0 1.7-3l-7.6-13.1a2 2 0 0 0-3.4 0Z"/></svg>';
  return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8v5m0 4h.01"/><circle cx="12" cy="12" r="9"/></svg>';
}

function renderAnalysis(result) {
  const info = getStatusInfo(result.status);
  $("#analysis-placeholder").hidden = true;
  $("#analysis-result").hidden = false;
  $("#result-status-icon").className = `result-status-icon ${result.status}`;
  $("#result-status-icon").innerHTML = statusIconSVG(result.status);
  $("#result-label").className = `result-label ${result.status}`;
  $("#result-label").textContent = info.label;
  $("#result-headline").textContent = info.headline;
  $("#result-description").textContent = info.description;
  $("#risk-score").textContent = result.score;
  $("#risk-meter-fill").style.width = `${result.score}%`;
  $("#risk-meter-fill").style.background = result.status === "blocked" ? "#d86d69" : result.status === "review" ? "#d6a246" : "#54ac7f";
  $("#reason-list").innerHTML = result.reasons.map((reason) =>
    `<div class="reason-item ${reason.triggered ? "triggered" : ""}"><span class="reason-mark">${reason.triggered ? "!" : "✓"}</span>${escapeHTML(reason.text)}</div>`
  ).join("");
}

function renderSessionActivity() {
  const container = $("#monitor-activity-list");
  const count = appState.sessionAnalyses.length;
  $("#monitor-session-count").textContent = `${count} ${count === 1 ? "análisis" : "análisis"}`;
  if (!count) {
    container.innerHTML = '<div class="activity-empty"><span class="activity-empty-icon">↗</span><span><strong>Aún no hay análisis en esta sesión</strong><small>Los resultados aparecerán aquí al probar una operación.</small></span></div>';
    return;
  }
  container.innerHTML = appState.sessionAnalyses.slice(0, 5).map((item) =>
    `<div class="monitor-activity-row"><span class="activity-marker ${item.status}"></span><span class="activity-detail"><strong>${escapeHTML(item.id)}</strong> · ${escapeHTML(item.location)} · ${formatCurrency(item.amount)}</span><span class="status-pill status-${item.status}">${getStatusInfo(item.status).label}</span><span class="activity-time">${escapeHTML(item.time)}</span></div>`
  ).join("");
}

function handleTransactionSubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  const amount = Number(formData.get("amount"));
  if (!Number.isFinite(amount) || amount <= 0) {
    $("#amount-input").focus();
    showToast("Ingresa un monto mayor que cero para continuar.");
    return;
  }

  const result = classifyTransaction(formData);
  const time = new Intl.DateTimeFormat("es-CO", { hour: "2-digit", minute: "2-digit" }).format(new Date());
  const id = `FC-${String(1049 + appState.sessionAnalyses.length).padStart(4, "0")}`;
  result.id = id;
  result.time = time;
  result.customer = "Prueba interactiva";
  result.merchant = $("#merchant-input").selectedOptions[0].textContent;
  result.category = result.merchant;
  result.initials = "PI";
  result.device = formData.get("device") === "new" ? "Nuevo" : "Habitual";
  appState.sessionAnalyses.unshift(result);
  appState.transactions.unshift(result);

  renderAnalysis(result);
  renderSessionActivity();
  updateOverview();
  showToast(`Análisis de ejemplo completado: ${getStatusInfo(result.status).label.toLocaleLowerCase("es")}.`);
}

function downloadCSV() {
  const rows = [
    ["ID", "Cliente", "Comercio", "Categoría", "Monto COP", "Ubicación", "Hora", "Puntaje de riesgo", "Estado"],
    ...getFilteredTransactions().map((item) => [
      item.id, item.customer, item.merchant, item.category, item.amount,
      item.location, item.time, item.score, getStatusInfo(item.status).label
    ])
  ];
  const csv = rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "fraudecheck-transacciones-demo.csv";
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  showToast("CSV de la muestra descargado.");
}

function initializeApp() {
  $("#today-label").textContent = new Intl.DateTimeFormat("es-CO", {
    weekday: "short", day: "2-digit", month: "short", year: "numeric"
  }).format(new Date()).replace(/\./g, "");
  $("#metric-total").textContent = formatNumber(REFERENCE_METRICS.totalProcessed);
  $$(".nav-item").forEach((item) => item.addEventListener("click", () => setPage(item.dataset.page)));
  $$("[data-page-link]").forEach((item) => item.addEventListener("click", (event) => {
    event.preventDefault();
    setPage(item.dataset.pageLink);
  }));
  $$("[data-go-page]").forEach((item) => item.addEventListener("click", () => setPage(item.dataset.goPage)));

  $("#mobile-menu-button").addEventListener("click", toggleMobileMenu);
  $("#sidebar-backdrop").addEventListener("click", closeMobileMenu);
  $("#transaction-form").addEventListener("submit", handleTransactionSubmit);
  $("#transaction-search").addEventListener("input", renderDataTable);
  $("#status-filter").addEventListener("change", renderDataTable);
  $("#risk-filter").addEventListener("change", renderDataTable);
  $("#export-button").addEventListener("click", downloadCSV);
  $("#clear-filters").addEventListener("click", () => {
    $("#transaction-search").value = "";
    $("#status-filter").value = "all";
    $("#risk-filter").value = "all";
    renderDataTable();
  });

  updateOverview();
  renderDataTable();
}

document.addEventListener("DOMContentLoaded", initializeApp);